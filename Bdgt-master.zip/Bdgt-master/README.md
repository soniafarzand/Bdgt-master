# Bdgt
A simple Android app for budgeting and tracking your daily expenses.
![Budget app](https://raw.githubusercontent.com/chanakyabhardwajj/Bdgt/master/play_store_graphics/Budget-feature-graphic.png)
![List screen](https://raw.githubusercontent.com/chanakyabhardwajj/Bdgt/c90cfef1d913731d247a49f35b3160ca92b8f13d/app/src/main/res/play_store_graphics/list_screen.png)
![Detail screen](https://raw.githubusercontent.com/chanakyabhardwajj/Bdgt/c90cfef1d913731d247a49f35b3160ca92b8f13d/app/src/main/res/play_store_graphics/detail_screen.png)
